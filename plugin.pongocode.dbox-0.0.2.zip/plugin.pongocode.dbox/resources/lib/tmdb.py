import requests
import json

class tmdb():
    def tmdb_title(type, search_query):
        key = '95b1a7ad3063ce0cfaa51e6b15cb5820'
        # type = 'multi'  # tv / movie / multi 중에 선택 나는 multi 선택
        url = f"http://api.themoviedb.org/3/search/{type}?api_key={key}&query={search_query}"
        r = requests.get(url)
        res = r.content.decode()
        json_obj = json.loads(res)
        print(json_obj['results'])

        for elem in json_obj['results']:
            try:
                return elem['original_name']
            except:
                return elem['original_title']

        # for elem in json_obj['results']:
        #     try:
        #         f"{elem['original_name']} ({elem['first_air_date'][:4]}) | {elem['name']}"
        #     except:
        #         # print(elem["original_title"] + " (" + elem["title"] + ")")
        #         f"{elem['original_title']} ({elem['release_date'][:4]}) | {elem['title']}"

    def tmdb_plot(type, search_query):
        key = '95b1a7ad3063ce0cfaa51e6b15cb5820'
        # type = 'multi'  # tv / movie / multi 중에 선택 나는 multi 선택
        url = f"http://api.themoviedb.org/3/search/{type}?api_key={key}&query={search_query}"
        r = requests.get(url)
        res = r.content.decode()
        json_obj = json.loads(res)
        print(json_obj['results'])

        for elem in json_obj['results']:
            return elem['overview']