from __future__ import unicode_literals

from codequick import Route, Resolver, Listitem, run
# from codequick.utils import urljoin_partial, bold

import json
import requests
import re

headers = {
    'origin': 'https://tvchak.com',
    'referer': 'https://tvchak.com',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.41 Safari/537.36'
    }


@Route.register
def root(plugin, content_type="segment"):

    yield Listitem.search(list_search)

    item = Listitem()
    item.label = "드라마"
    item.set_callback(list_multi, type_multi="drama", page_no=1)
    yield item

    item = Listitem()
    item.label = "오리지널"
    item.set_callback(list_multi, type_multi="original", page_no=1)
    yield item

    item = Listitem()
    item.label = "영화"
    item.set_callback(list_multi, type_multi="movies", page_no=1)
    yield item

    item = Listitem()
    item.label = "예능"
    item.set_callback(list_multi, type_multi="variety", page_no=1)
    yield item


    item = Listitem()
    item.label = "Etc"
    item.set_callback(etc)
    item
    yield item


@Route.register
def etc(plugin, content_type="segment"):


    item = Listitem()
    item.label = "다큐/시사"
    item.set_callback(list_multi, type_multi="tv", page_no=1)
    yield item

    item = Listitem()
    item.label = "애니"
    item.set_callback(list_multi, type_multi="ani", page_no=1)
    yield item

@Route.register
def list_search(plugin, search_query):

    data = {'keyword': f"{search_query}"}
    r = requests.post('https://tvchak.com/api/search/', headers=headers, data=data, verify=False)
    res = r.content.decode()
    json_obj = json.loads(res)
    #메인 검색어
    for elem in json_obj[1]["apiData"]["dataAll"]:
        item = Listitem()
        item.label = elem["title"]
        item.art["thumb"] = elem["posterImgUrl"]
        item.art["fanart"] = ''
        item.info["plot"] = ''
         # 미디어 타입 분석기 (Start)
        if not "movies" in elem["category"]:
            item.set_callback(
                open_episodes,
                epi_code = elem["code"],
                epi_page = 1
            )                        
            yield item
        else:
            item.set_callback(
                open_video,
                video_url = "https://luckynews.freestream24.com/player/vod/?e=" + elem["ve_code"],
                video_title = elem["title"]
            )
            yield item

    # yield Listitem.next_page(search_query=f"{search_query}")

@Route.register
def list_multi(plugin, type_multi, page_no):

    #영화만 따로
    if type_multi == "movies":        
        data = {
            'page_now': f"{page_no}",
            'category': f"{type_multi}",
            'order': 'movies_newest',
            'page_set': '30'
            }
    else:
        data = {
            'page_now': f"{page_no}",
            'category': f"{type_multi}",
            'order': 'newest',
            'page_set': '30'

            } 

    r = requests.post('https://tvchak.com/api/vod/mainchannel.php', headers=headers, data=data, verify=False)
    res = r.content.decode()
    json_obj = json.loads(res)

    for elem in json_obj['dataAll']:
        item = Listitem()
        item.label = elem["title"]
        item.art.icon = ""
        item.art["thumb"] = elem["posterImgUrl"]
        item.art["fanart"] = ""
        
        if not "movies" in elem["category"]:
            item.set_callback(
                open_episodes,
                epi_code = elem["code"],
                epi_page = 1
            )                        
            yield item
        else:
            item.set_callback(
                open_video,
                video_url = "https://luckynews.freestream24.com/player/vod/?e=" + elem["ve_code"],
                video_title = elem["title"]
            )
            yield item
            
    yield Listitem.next_page(type_multi=f"{type_multi}", page_no=page_no + 1, callback=list_multi)


@Route.register
def open_episodes(plugin, epi_code, epi_page):

    data_epi = {
    'vod_main_code': f"{epi_code}",
    'page_now': f"{epi_page}",
    'order': 'newest',
    'page_set': '20'}
    
     
    r = requests.post('https://tvchak.com/api/vod/episode.php', headers=headers, data=data_epi, verify=False)
    res = r.content.decode()
    json_obj = json.loads(res)

    for elem in json_obj['dataAll']:
        elem_title = elem['episodeTitle'] + "       |   " + elem["date"] + " (" + elem["dateWeek"] + ")"
        elem_desc = elem["desc"].replace("<br />", "")

        item = Listitem()
        item.label = elem_title
        item.art["thumb"] = elem["thumbnailImgUrl"]
        item.art["fanart"] = ""
        item.info["plot"] = elem_desc        
        
        item.set_callback(
            open_video,
            video_url = "https://luckynews.freestream24.com/player/vod/?e=" + elem["code"],
            video_title = elem["mainTitle"] + " - " + elem["episodeTitle"]
            )

        yield item

        # 페이지 추가
    if str(json_obj['pageNow']) < str(json_obj['lastPage']):            
        yield Listitem.next_page(epi_code=f"{epi_code}", epi_page = epi_page + 1, callback = open_episodes)



        


@Route.register
def get_video_url(episode_url):

    header = {'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.124 Safari/537.36'
    , 'Referer' : 'https://tvchak.com', 'Origin' : 'https://luckynews.freestream24.com'
           }

    regex = r'(\bhttps:.+m3u8\b)'

    r = requests.post(episode_url, headers=header, verify=False)
    res = r.content.decode()
    raw_url = re.findall(regex, res)
    final_url = raw_url[0].replace("\/","/")
    return final_url


@Resolver.register
def open_video(plugin, video_url, video_title):

    vid_url = f"{get_video_url(video_url)}|User-Agent={headers['user-agent']}&Referer=https://luckynews.freestream24.com"
    return Listitem().from_dict(**{
        "label": video_title,
        "callback" : vid_url,
        "properties": {
            "inputstream.adaptive.manifest_type": "hls",
            "inputstream": "inputstream.adaptive"
        }
    })