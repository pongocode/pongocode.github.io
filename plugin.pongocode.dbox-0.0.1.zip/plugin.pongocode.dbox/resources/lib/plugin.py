from __future__ import unicode_literals
from codequick import Route, Resolver, Listitem, run
from codequick.utils import urljoin_partial, bold
from bs4 import BeautifulSoup
import requests
import urlquick
import re
import json
import xbmc, xbmcaddon, xbmcgui

settings = xbmcaddon.Addon().getSetting
default_stream = settings('default_stream')


# item.info["plot"] = f"[COLOR green]{tmdb_title('multi', elem_title)}[/COLOR]\n{tmdb_plot('multi', elem_title)}"
# resolved = resolveurl.resolve(json_obj['link'])  # resolveurl 사용!

headers = {
    'origin': 'https://dopebox.to',
    'referer': 'https://dopebox.to',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.41 Safari/537.36'
}

base_url = "https://dopebox.to"


@Route.register
def root(plugin):
    yield Listitem.search(list_search, page_no=1)

    item = Listitem()
    item.label = "TV Shows - South Korea"
    item.set_callback(list_multi, type_multi="tv", country="135", page_no=1)
    yield item

    item = Listitem()
    item.label = "TV Shows - USA & UK"
    item.set_callback(list_multi, type_multi="tv", country="180-129", page_no=1)
    yield item

    item = Listitem()
    item.label = "Movies - South Korea"
    item.set_callback(list_multi, type_multi="movie", country="135", page_no=1)
    yield item

    item = Listitem()
    item.label = "Movies - USA & UK"
    item.set_callback(list_multi, type_multi="movie", country="180-129", page_no=1)
    yield item


@Route.register  # 서치 디렉토리
def list_search(plugin, search_query, page_no):
    search_replace = search_query.replace(" ", "-")
    url = f"{base_url}/search/{search_replace}?page={page_no}"

    r = requests.get(url, headers=headers)
    res = BeautifulSoup(r.text, 'html.parser')
    elem_root = res.select_one('div.film_list-wrap')

    for elem in elem_root.select('div.flw-item'):

        elem_img = elem.select_one('img')['data-src']
        elem_title = elem.select_one('a')['title']
        elem_url = elem.select_one('a')['href']
        elem_detail = elem.select_one('div.film-detail > div.fd-infor > span:last-child').text

        item = Listitem()
        item.label = f"{elem_title} ({elem_detail})"
        item.art["thumb"] = elem_img
        item.art["fanart"] = elem_img

        if "tv" in elem_url:
            item.set_callback(
                open_tv_movie,
                vid_code=elem_url,
                vid_title=elem_title,
                vid_img=elem_img
            )
            yield item

        else:
            item.set_callback(
                open_tv_movie,
                vid_code=elem_url,
                vid_title=f"{elem_title} ({elem_detail})",   #여기 고쳐야됨 년도가 안나옴
                vid_img=elem_img
            )
            yield item


    if "page-item" in res:
        yield Listitem.next_page(page_no=page_no + 1, search_query=f"{search_query}", callback=list_search)
    else:
        pass



@Route.register
def list_multi(plugin, type_multi, country, page_no):
    url = f"{base_url}/filter?type={type_multi}&quality=all&release_year=all&genre=all&country={country}]&page={page_no}"
    r = requests.get(url, headers=headers)
    res = BeautifulSoup(r.content, 'html.parser')
    elem_root = res.select_one('div.film_list-wrap')  # 복잡하니 살려둔다

    for elem in elem_root.select('div.flw-item'):
        elem_img = elem.select_one('img')['data-src']
        elem_title = elem.select_one('a')['title']
        elem_url = elem.select_one('a')['href']
        elem_detail = elem.select_one('div.film-detail > div.fd-infor > span:last-child').text

        item = Listitem()

        item.label = f"{elem_title} ({elem_detail})"

        item.art.icon = elem_img
        item.art["thumb"] = elem_img
        item.art["fanart"] = elem_img

        if type_multi == "tv":
            item.set_callback(
                open_tv_movie,
                vid_code=elem_url,
                vid_title=elem_title,
                vid_img=elem_img
            )
            yield item
        else:
            item.set_callback(
                open_tv_movie,
                vid_code=elem_url,
                vid_title=f"{elem_title} ({elem_detail})",
                vid_img=elem_img
            )
            yield item



    # 페이지 넘기기
    if "page-item" in res:
        yield Listitem.next_page(type_multi=f"{type_multi}", country=f"{country}", page_no=page_no + 1,
                                 callback=list_multi)
    else:
        pass


@Route.register
def open_tv_movie(plugin, vid_code, vid_title, vid_img):
    if "tv" in vid_code:  # TV 시즌 오픈
        url = base_url + "/ajax/v2/tv/seasons/" + vid_code.split('-')[-1]
        r = requests.get(url, headers=headers)
        res = BeautifulSoup(r.content, 'html.parser')

        for elem in res.select('a[class="dropdown-item ss-item"]'):
            elem_title = elem.text.strip()
            elem_code = elem['data-id']

            item = Listitem()
            item.label = f"{elem_title}   |   {vid_title}"
            item.art["thumb"] = vid_img
            item.set_callback(
                open_episodes,
                vid_code=elem_code,
                vid_title=f"{vid_title} {elem_title}"  # 타이틀 + 시즌
            )
            yield item

    else:  # 소스 나오는 페이지로 토스
        item = Listitem()
        item.label = f"Watch   |   {vid_title}"
        item.art["thumb"] = vid_img
        item.info["plot"] = "준비중"
        item.set_callback(
            play_video,
            vid_code=vid_code.split('-')[-1],
            vid_title=f"{vid_title}",
            vid_data="1"
        )
        yield item


@Route.register
def open_episodes(plugin, vid_code, vid_title):
    ajax = base_url + "/ajax/v2/season/episodes/" + vid_code  # 시즌 아이디 첨부
    r = requests.get(ajax, headers=headers)
    res = BeautifulSoup(r.content, 'html.parser')

    for elem in res.select('div[class="flw-item film_single-item episode-item eps-item"]'):
        elem_title = elem.select_one('a > img')['alt']
        e_title_r = elem_title.split(" ")[-1].zfill(2)
        e_title_l = elem_title.split(" ")[0]
        e_title = f"{e_title_l} {e_title_r}"

        item = Listitem()
        item.label = f"{e_title}   |   {vid_title}"
        item.art["thumb"] = elem.select_one('a > img')['src']
        item.art["fanart"] = elem.select_one('a > img')['src']
        # item.info["plot"] = elem.select_one('a > img')['alt']
        item.set_callback(
            play_video,
            vid_code=elem['data-id'],
            # vid_title=f"{vid_title}E{convertt(elem_title)}",
            vid_title=f"{vid_title} {elem_title}",  # 타이틀 + 시즌 + 에피소드
            vid_data="2"
        )
        yield item


def open_sources(vid_code, vid_data):
    if vid_data == "2":
        ajax = "/ajax/v2/episode/servers/"
    else:
        ajax = "/ajax/movie/episodes/"

    url = base_url + ajax + vid_code
    r = requests.get(url, headers=headers)
    res = BeautifulSoup(r.content, 'html.parser')

    for elem in res.select('li > a'):
        if elem.find("span").text == default_stream:
            source_code = elem['data-id']
            xbmc.log(f"##### [Now Playing : {default_stream}] 로 실행중... #####", xbmc.LOGINFO)
            break
        # else:
        #     xbmcgui.Dialog().ok("에러", "스트림을 찾을 수 없습니다.")

        # 세팅으로 만든걸로 변경
        # if 'Vidcloud' in elem.find("span").text:
        #     source_code = elem.select_one('a')['data-id']
        #     break
        # elif 'Streamlare' in elem.find("span").text:
        #     source_code = elem.select_one('a')['data-id']
        #     break

    # resolveurl 사용
    url = base_url + "/ajax/get_link/" + source_code
    r = requests.get(url, headers=headers)
    res = r.content.decode()
    json_obj = json.loads(res)
    import resolveurl
    resolved = resolveurl.resolve(json_obj['link'])  # resolveurl 사용!
    return resolved


    # return url_helper(source_code) # 직접 resolve 꼭 해내자

# def url_helper(source_code):
#     regx_code = r"(?:rabbitstream.net\/embed-4\/)([a-zA-Z0-9_]*)"
#     regx_m3u8 = r'(\bhttps:.+m3u8\b)'
#
#     url = base_url + "/ajax/get_link/" + source_code
#     r = requests.get(url, headers=headers)
#     res = r.content.decode()
#     # json_obj = json.loads(res)
#
#     # regxed = re.findall(regx, json_obj['link'])
#     regx_ = re.findall(regx_code, res)
#     url2 = "https://mzzcloud.life/ajax/embed-4/getSources?id=" + regx_[0]
#
#     # print(res)
#     r2 = requests.get(url2, headers=headers)
#
#     resolved = re.findall(regx_m3u8, r2.text)
#     return resolved[0]

@Resolver.register
def play_video(plugin, vid_code, vid_title, vid_data):
    vid_url = open_sources(vid_code, vid_data)
    return Listitem().from_dict(**{
        "label": clean_text(vid_title),
        "callback": vid_url,
        "properties": {
            'inputstream.adaptive.manifest_type': "hls",
            'inputstream': "inputstream.adaptive"
        }
    })

def clean_text(inputString):
  text_rmv = re.sub('[=+,&$#/\?:^.@*\"※~ㆍ!』‘|\(\)\[\]`\'…》\”\“\’·]', '', inputString)
  return text_rmv

# def convertt(title):
#     if 'Season' or 'season' or 'Episode' or 'episode' in title:
#         zfilled = title.split(" ")[-1].zfill(2)
#         return zfilled                 # 아직은 쓸일없음
