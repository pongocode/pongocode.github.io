from __future__ import unicode_literals
from codequick import Route, Resolver, Listitem, run
from codequick.utils import urljoin_partial, bold
from bs4 import BeautifulSoup
import requests
import urlquick
import re
import json
import resolveurl

# from resources.lib.dbox import lists, modules, open, play

headers = {
    'origin': 'https://dopebox.to',
    'referer': 'https://dopebox.to',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.41 Safari/537.36'
}

@Route.register
def root(plugin):

    yield Listitem.search(list_search, page_no=1)

    item = Listitem()
    item.label = "TV Shows - South Korea"
    item.set_callback(list_multi, type_multi="tv", country="135", page_no=1)
    yield item

    item = Listitem()
    item.label = "TV Shows - USA & UK"
    item.set_callback(list_multi, type_multi="tv", country="180-129", page_no=1)
    yield item

    item = Listitem()
    item.label = "Movies - South Korea"
    item.set_callback(list_single, type_single="movie", country="135", page_no=1)
    yield item

    item = Listitem()
    item.label = "Movies - USA & UK"
    item.set_callback(list_single, type_single="movie", country="180-129", page_no=1)
    yield item

@Route.register     # 서치 디렉토리
def list_search(plugin, search_query, page_no):

    search_replace = search_query.replace(" ", "-")
    url = f"http://dopebox.to/search/{search_replace}?page={page_no}"

    r = requests.get(url, headers=headers)
    res = BeautifulSoup(r.text, 'html.parser')
    elem_root = res.select_one('div.film_list-wrap')

    for elem in elem_root.select('div.flw-item'):

        elem_img = elem.select_one('img')['data-src']
        elem_title = elem.select_one('a')['title']
        elem_url = elem.select_one('a')['href']
        elem_detail = elem.select_one('div.film-detail > div.fd-infor > span:nth-child(3)')


        item = Listitem()
        try:
            item.label = f"{elem_title} ({elem_detail.text})"  #타이틀 연도
        except:
            continue
        item.art["thumb"] = elem_img
        item.art["fanart"] = elem_img
        # item.info["plot"] = f"[COLOR green]{tmdb_title('multi', elem_title)}[/COLOR]\n{tmdb_plot('multi', elem_title)}"

        if not "movie" in elem_url:    #무비의 경우 다르게 해야됨

            item.set_callback(
                open_seasons,
                vid_code = elem_url.split('-')[-1],
                vid_title = elem_title
            )
        else:
            item.set_callback(
                play_movie,
                vid_code=elem_url.split('-')[-1],
                vid_title=f"{elem_title} ({elem_detail.text})"
            )

        yield item

    yield Listitem.next_page(page_no=page_no + 1, search_query=f"{search_query}", callback=list_search)

@Route.register
def list_multi(plugin, type_multi, country, page_no):

    url = f'https://dopebox.to/filter?type={type_multi}&quality=all&release_year=all&genre=all&country={country}]&page={page_no}'
    r = requests.get(url, headers=headers)
    res = BeautifulSoup(r.content, 'html.parser')
    elem_root = res.select_one('div.film_list-wrap')  # 복잡하니 살려둔다

    for elem in elem_root.select('div.flw-item'):
        elem_img = elem.select_one('img')['data-src']
        elem_title = elem.select_one('a')['title']
        elem_url = elem.select_one('a')['href']
        # elem_url = elem.select_one('a')['href'].split('-')[-1]  # split으로 코드만 따기
        elem_detail = elem.select_one('div.film-detail > div.fd-infor > span:nth-child(3)')

        item = Listitem()    # 트라이를 안쓰면 에러가남? 이유는 모름
        try:
            item.label = f"{elem_title} ({elem_detail.text})"
        except:
            continue
        item.art.icon = elem_img
        item.art["thumb"] = elem_img
        item.art["fanart"] = elem_img
        # item.info["plot"] = elem_title
        item.set_callback(
            open_seasons,
            vid_code=elem_url,
            vid_title=elem_title
        )
        yield item
    yield Listitem.next_page(type_multi=f"{type_multi}", country=f"{country}", page_no=page_no + 1, callback=list_multi)

@Route.register
def list_single(plugin, type_single, country, page_no):

    url = f'https://dopebox.to/filter?type={type_single}&quality=all&release_year=all&genre=all&country={country}&page={page_no}'
    resp = requests.get(url, headers=headers)
    soup = BeautifulSoup(resp.content, "html.parser")

    r = requests.get(url, headers=headers)
    res = BeautifulSoup(r.content, 'html.parser')
    elem_root = res.select_one('div.film_list-wrap')

    for elem in elem_root.select('div.flw-item'):
        elem_img = elem.select_one('img')['data-src']
        elem_title = elem.select_one('a')['title']
        elem_url = elem.select_one('a')['href']  # 아직 split을 하지 않는 이유는 tv/show if문 돌리기 위해
        # elem_url = elem.select_one('a')['href'].split('-')[-1] # split으로 뒤에 코드만 따기
        elem_detail = elem.select_one('div.film-detail > div.fd-infor > span:nth-child(3)')

        item = Listitem()
        try:
            item.label = f"{elem_title} ({elem_detail.text})"
        except:
            continue
        item.art.icon = elem_img
        item.art["thumb"] = elem_img
        item.art["fanart"] = elem_img
        # item.info["plot"] = f"[COLOR green]{tmdb_title('movie', elem_title)}[/COLOR]\n{tmdb_plot('movie', elem_title)}"

        item.set_callback(
            play_movie,
            vid_code=elem_url,   # elem_url 로 movie/~~~ url이 전송된다
            vid_title=f"{elem_title}  ({elem_detail.text})"
        )
        yield item

    yield Listitem.next_page(type_single=f"{type_single}", country=country, page_no=page_no + 1, callback=list_single)

@Route.register
def open_seasons(plugin, vid_code, vid_title):
    # tv - parse > code_seasons > code_episodes > code_sources
    # movie - parse > code_seasons 이걸 곧바로 code_sources 로 보냄
    url = 'https://dopebox.to/ajax/v2/tv/seasons/' + vid_code.split('-')[-1]  # 스플릿해서 코드만 줌
    r = requests.get(url, headers=headers)
    res = BeautifulSoup(r.content, 'html.parser')

    #해야할것 season 2가 없으면 season 1 으로 바로 이동

    for elem in res.select('div[class="dropdown-menu dropdown-menu-model"] > a'):
        elem_title = elem.text.strip()
        item = Listitem()
        item.label = elem_title
        item.set_callback(
            open_episodes,
            vid_code=elem['data-id'],
            vid_title=f"{vid_title}.S{convertt(elem_title)}"  # convert한 제목
        )
        yield item


@Route.register
def open_episodes(plugin, vid_code, vid_title):
    url = 'https://dopebox.to/ajax/v2/season/episodes/' + vid_code  # 시즌 아이디 첨부
    r = requests.get(url, headers=headers)
    res = BeautifulSoup(r.content, 'html.parser')

    for elem in res.select('div[class="flw-item film_single-item episode-item eps-item"]'):
        elem_title = elem.select_one('a > img')['alt']
        item = Listitem()
        item.label = elem_title
        item.art["thumb"] = elem.select_one('a > img')['src']
        item.art["fanart"] = elem.select_one('a > img')['src']
        # item.info["plot"] = elem.select_one('a > img')['alt']
        item.set_callback(
            play_video,
            vid_code=elem['data-id'],
            vid_title=f"{vid_title}E{convertt(elem_title)}"
        )
        yield item


def open_sources(vid_code):
    url = 'https://dopebox.to/ajax/v2/episode/servers/' + vid_code
    r = requests.get(url, headers=headers)
    res = BeautifulSoup(r.content, 'html.parser')

    for elem in res.select('li'):
        # VidCloud or Streamlare 에서 링크 추출

        if 'Vidcloud' in elem.find("span").text:
            vid_code = elem.select_one('a')['data-id']
            break

        elif 'Streamlare' in elem.find("span").text:
            vid_code = elem.select_one('a')['data-id']
            break

    url = 'https://dopebox.to/ajax/get_link/' + vid_code
    r = requests.get(url, headers=headers)
    res = r.content.decode()
    json_obj = json.loads(res)

    resolved = resolveurl.resolve(json_obj['link'])  # resolveurl 사용!
    return resolved


def open_movies(vid_code):
    url = 'https://dopebox.to/ajax/movie/episodes/' + vid_code.split('-')[-1]
    r = requests.get(url, headers=headers)
    res = BeautifulSoup(r.content, 'html.parser')

    for elem in res.select('li'):
        if 'Vidcloud' in elem.find("span").text:
            vid_code = elem.select_one('a')['data-id']
            break  # 이게 있어야 for문 멈춰서 잘나옴

        elif 'Streamlare' in elem.find("span").text:
            vid_code = elem.select_one('a')['data-id']

    url = 'https://dopebox.to/ajax/get_link/' + vid_code
    r = requests.get(url, headers=headers)
    res = r.content.decode()
    json_obj = json.loads(res)

    resolved = resolveurl.resolve(json_obj['link'])  # resolveurl 사용!

    return resolved

@Resolver.register
def play_video(plugin, vid_code, vid_title):

    vid_url = open_sources(vid_code)
    return Listitem().from_dict(**{
        "label": vid_title,
        "callback": vid_url,
        "properties": {
            "inputstream.adaptive.manifest_type": "hls",
            "inputstream": "inputstream.adaptive"
        }
    })


@Resolver.register   #임시로 빨리 만들고보자 코드 더러워짐
def play_movie(plugin, vid_code, vid_title):

    vid_url = open_movies(vid_code)
    return Listitem().from_dict(**{
        "label": vid_title,
        "callback": vid_url,
        "properties": {
            "inputstream.adaptive.manifest_type": "hls",
            "inputstream": "inputstream.adaptive"
        }
    })

def tmdb_title(type, search_query):
    key = '95b1a7ad3063ce0cfaa51e6b15cb5820'
    # type = 'multi'  # tv / movie / multi 중에 선택 나는 multi 선택
    url = f"http://api.themoviedb.org/3/search/{type}?api_key={key}&query={search_query}"
    r = requests.get(url)
    res = r.content.decode()
    json_obj = json.loads(res)
    print(json_obj['results'])

    for elem in json_obj['results']:
        try:
            return elem['original_name']
        except:
            return elem['original_title']

    # for elem in json_obj['results']:
    #     try:
    #         f"{elem['original_name']} ({elem['first_air_date'][:4]}) | {elem['name']}"
    #     except:
    #         # print(elem["original_title"] + " (" + elem["title"] + ")")
    #         f"{elem['original_title']} ({elem['release_date'][:4]}) | {elem['title']}"

def tmdb_plot(type, search_query):
    key = '95b1a7ad3063ce0cfaa51e6b15cb5820'
    # type = 'multi'  # tv / movie / multi 중에 선택 나는 multi 선택
    url = f"http://api.themoviedb.org/3/search/{type}?api_key={key}&query={search_query}"
    r = requests.get(url)
    res = r.content.decode()
    json_obj = json.loads(res)
    print(json_obj['results'])

    for elem in json_obj['results']:
        return elem['overview']

def convertt(title):
    if 'Season' or 'season' or 'Episode' or 'episode' in title:
        zfilled = title.split(" ")[-1].zfill(2)
        return zfilled