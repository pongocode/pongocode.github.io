from __future__ import unicode_literals

from codequick import Route, Resolver, Listitem, run
from codequick.utils import urljoin_partial, bold
from bs4 import BeautifulSoup

import requests
import urlquick
import re


base_url = "https://noonoo.tv"
headers = {'User-Agent' : 'Mozilla/5.0', 'Referer' : 'https://noonoo.tv'}


def get_video_url(episode_url):

    regex = r'(\bhttps://cdn.+m3u8\b)'

    res = requests.get(episode_url).text
    soup = BeautifulSoup(res, "html.parser")
    stream_link = soup.find('lite-iframe')['src']
    res2 = requests.get(stream_link, headers=headers).text
    soup2 = BeautifulSoup(res2, "html.parser")

    stream_source = soup2.select("script")

    final_url = re.findall(regex, str(stream_source))[0]

    return final_url




@Route.register
def root(plugin, content_type="segment"):
    yield Listitem.search(search_drama)

    item = Listitem()
    item.label = "Korean Drama"
    item.set_callback(list_drama, page_no=1)

    yield item

@Route.register
def search_drama(plugin, search_query):
    # 페이지 넘기는거 나중에 !!

    search_url = f"{base_url}/search?sfl=common_title%7C%7Cseason_title&stx={search_query}"

    resp = requests.get(search_url)
    soup = BeautifulSoup(resp.content, "html.parser")

    drama_images = soup.findAll('a', {'class': 'thumb-images'})
    drama_titles = soup.findAll('div', {'class': 'result-lot'})




    for image, title in zip(drama_images, drama_titles):
        drama_title = title.findAll('a', {'class': 'se-title'})
        drama_image = image.findAll('img')
        drama_plot = title.findAll('p')

        # 미디어 타입 콜
        media_type = drama_title[0]["href"].split("/")[-2:-1]
        media_multi = ['drama', 'entertainment', 'documentary', 'animation', 'en_drama']
        # media_adult = 'adult_movie'


        item = Listitem()
        item.label = drama_title[0].text
        item.art["thumb"] = drama_image[0]['src']
        item.art["fanart"] = drama_image[0]['src']
        item.info["plot"] = drama_plot[0].text


        # 미디어 타입 분석기 (Start)
        if media_type[0] in media_multi:
            item.set_callback(
                get_episodes,
                drama_url=drama_title[0]["href"],
                img_url=drama_image[0]["src"])
            yield item
        else:
            item.set_callback(
                play_video,
                video_url=drama_title[0]["href"],
                v_title=drama_title[0].text)

            yield item

    yield Listitem.next_page(next_page, callback=search_drama)


@Route.register
def list_drama(plugin, page_no=1):

    drama_url = f"https://noonoo.tv/drama?page={page_no}"
    resp = urlquick.get(drama_url, max_age=-1)
    soup = resp.parse("ul", attrs={"id": "items_rows_box"})

    drama_images = soup.iterfind("li/a/img")
    drama_titles = soup.iterfind("li/div/p/a")

    for drama_image, drama_title in zip(drama_images, drama_titles):

        item = Listitem()
        item.label = drama_title.text
        item.art["thumb"] = drama_image.get("data-src")
        item.art["fanart"] = drama_image.get("data-src")
        item.info["plot"] = f"Watch {drama_title.text}"

        item.set_callback(
            get_episodes,
            drama_url=drama_title.get("href"),
            img_url=drama_image.get("data-src"))

        yield item


    yield Listitem.next_page(page_no + 1, callback=list_drama)

@Route.register
def get_episodes(plugin, drama_url, img_url):

    resp = requests.get(drama_url)
    soup = BeautifulSoup(resp.content, "html.parser")
    episodes = soup.findAll('div', {'class': 'post-episode'})

    for lists in episodes:
        episode = lists.find('a')
        item = Listitem()
        item.art["thumb"] = img_url
        item.art["fanart"] = img_url
        item.label = f"{episode.text}"

        item.set_callback(
            play_video,
            video_url=episode.get("href"),
            v_title=f"{episode.text}")

        yield item

@Resolver.register
def play_video(plugin, video_url, v_title):

    vid_url = f"{get_video_url(video_url)}|User-Agent={headers['User-Agent']}&Referer=https://studiouniversal.net"
    return Listitem().from_dict(**{
        "label": v_title,
        "callback" : vid_url,
        "properties": {
            "inputstream.adaptive.manifest_type": "hls",
            "inputstream": "inputstream.adaptive"
        }
    })