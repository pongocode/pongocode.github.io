from __future__ import unicode_literals

from codequick import Route, Resolver, Listitem, run
from codequick.utils import urljoin_partial, bold
from bs4 import BeautifulSoup


import requests
import urlquick
import re

headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36', 'Referer': 'https://noonoo.tv'}
# headers = {'User-Agent' : 'Mozilla/5.0', 'Referer' : 'https://noonoo.tv'}
base_url = "https://noonoo.tv"


@Route.register
def root(plugin, content_type="segment"):

    yield Listitem.search(list_search, page_no=1)

    item = Listitem()
    item.art.icon = 'https://cdn-icons-png.flaticon.com/128/2502/2502208.png'
    item.label = "한국 드라마 (K-DRAMA)"
    item.set_callback(list_multi, type_multi="drama", page_no=1)
    yield item

    item = Listitem()
    item.label = "예능 (TV Show)"
    item.set_callback(list_multi, type_multi="entertainment", page_no=1)
    yield item

    item = Listitem()
    item.label = "한국영화 (K-Movie)"
    item.set_callback(list_single, type_single="kr_movie", page_no=1)
    yield item

    item = Listitem()
    item.label = "해외영화 (Movie)"
    item.set_callback(list_single, type_single="en_movie", page_no=1)
    yield item

    item = Listitem()
    item.label = "Etc"
    item.set_callback(etc)
    item
    yield item


@Route.register
def etc(plugin, content_type="segment"):


    item = Listitem()
    item.label = "다큐 / 시사 (Documentary)"
    item.set_callback(list_multi, type_multi="documentary", page_no=1)
    yield item

    item = Listitem()
    item.label = "애니메이션 (Animation)"
    item.set_callback(list_multi, type_multi="animation", page_no=1)
    yield item

    item = Listitem()
    item.label = "해외 드라마 (DRAMA)"
    item.set_callback(list_multi, type_multi="en_drama", page_no=1)
    yield item

@Route.register
def list_search(plugin, search_query, page_no):

    url= f"{base_url}/search?sfl=common_title%7C%7Cseason_title&device=mobile&srows=10&stx={search_query}&page={page_no}"
    resp = requests.get(url, headers=headers)
    soup = BeautifulSoup(resp.content, "html.parser")
    #메인 검색어
    elem_root = soup.select_one('div[class=search-pages]')
    for elem in elem_root.select('div.result-lot'):

        elem_title = elem.select_one('a[class=se-title]')
        elem_plot = elem.select_one('div.lot-rows.overview > p')

        #elem_image
        if "noonoo-images" in str(elem):
            elem_image = elem.select_one('a.thumb-images > img')['src']
        else:
            elem_image = ''

        item = Listitem()
        item.label = elem_title.text
        item.art["thumb"] = elem_image
        item.art["fanart"] = elem_image
        item.info["plot"] = elem_plot.text

        # 미디어 타입 분석기 (Start)

        if not "movie" in elem_title["href"]:
            item.set_callback(
                open_episodes,
                url_title=elem_title["href"],
                url_img=elem_image
            )
            yield item
        else:
            item.set_callback(
                open_video,
                video_url=elem_title["href"],
                video_title=elem_title.text)

            yield item

    if "fal fa-angle-double-right" in str(soup):
        # pagination = soup.select_one('div[id=pagination] > div.next > a')
        # url_page = f"{base_url} + {pagination['href']}"
        yield Listitem.next_page(page_no=page_no + 1, search_query=f"{search_query}", callback=list_search)

@Route.register
def list_multi(plugin, type_multi, page_no):

    url = f"https://noonoo.tv/{type_multi}?device=mobile&page={page_no}"
    resp = requests.get(url, headers=headers)
    soup = BeautifulSoup(resp.content, "html.parser")

    elem_root = soup.select_one('div[class=list-content] > div[class=list-content-item] > ul[id=items_rows_box]')

    for elem in elem_root.select('li'):

        elem_title = elem.select_one('div[class=posted-info] > p[class=subject] > a')

        # 전체 파싱 elem에  if -> "https://noonoo-images..."가 있으면 추가, else -> 빈 url
        if "noonoo-images" in str(elem):
            elem_image = elem.select_one('a > img')['data-src']
        else:
            elem_image = ''

        item = Listitem()
        item.label = elem_title.text
        item.art.icon = elem_image
        item.art["thumb"] = elem_image
        item.art["fanart"] = elem_image
        item.info["plot"] = f"[COLOR green]{elem_title.text.strip()}[/COLOR]"
        item.set_callback(
            open_episodes,
            url_title=elem_title['href'],
            url_img=elem_image
                )
        yield item

    if "fal fa-angle-double-right" in str(soup):
        yield Listitem.next_page(type_multi=f"{type_multi}", page_no=page_no + 1, callback=list_multi)
    # yield Listitem.next_page(type_multi=f"{type_multi}", page_no=page_no + 1, callback=list_multi)


# # @Route.register     #링크에서 plot 가져오기 너무 느려서 못씀
# # def open_plot(plugin, url_content)
#     content_url = elem_title['href']
#     resp2 = requests.get(content_url)
#     soup2 = BeautifulSoup(resp2.content, "html.parser")
#
#         if "overview" in str(soup2):
#             elem_plot = soup2.select_one('div[class=overview] > p:nth-of-type(2)').text
#         else:
#             elem_plot = f"Watch {elem_title.text}"
#

@Route.register
def list_single(plugin, type_single, page_no):

    url = f"https://noonoo.tv/{type_single}?device=mobile&page={page_no}"
    resp = requests.get(url, headers=headers)
    soup = BeautifulSoup(resp.content, "html.parser")

    elem_root = soup.select_one('div[class=list-content] > div[class=list-content-item] > ul[id=items_rows_box]')
    # pagination = soup.select_one('div[id=container] > div[id=pagination] > div.next > a')
    # page_next = pagination['href'][-1]

    for elem in elem_root.select('li'):

        elem_title = elem.select_one('div[class=posted-info] > p[class=subject] > a')

        # 전체 파싱 elem에  if -> "https://noonoo-images..."가 있으면 추가, else -> 빈 url
        if "noonoo-images" in str(elem):
            elem_image = elem.select_one('a > img')['data-src']
        else:
            elem_image = ''

        item = Listitem()
        item.label = elem_title.text
        item.art["thumb"] = elem_image
        item.art["fanart"] = elem_image
        item.info["plot"] = f"[COLOR orchid]{elem_title.text.strip()}[/COLOR]"

        item.set_callback(
            open_video,
            video_url=elem_title["href"],
            video_title=elem_title.text)
        yield item

    if "fal fa-angle-double-right" in str(soup):
        yield Listitem.next_page(type_single=f"{type_single}", page_no=page_no + 1, callback=list_single)

@Route.register
def open_episodes(plugin, url_title, url_img):

    resp = requests.get(url_title)
    soup = BeautifulSoup(resp.content, "html.parser")
    elem_episodes = soup.select_one('ul[class=episode-content-item]')

    for elem in elem_episodes.select('li[class=content-box]'):

        elem_title = elem.select_one('div[class=post-episode] > h1 > a')
        elem_image = elem.select_one('div[class=thumb] > a > img')

        # title_text = elem_title.text.strip()
        # title_num = title_text.split(" ")[-1].zfill(3)
        # # title_only = title_text.strip(title_num)
        # # title_join = title_num + " - " + title_only

        item = Listitem()
        item.art["thumb"] = elem_image['data-src']
        item.art["fanart"] = url_img
        item.label = elem_title.text

        item.set_callback(
            open_video,
            video_url=elem_title['href'],
            video_title=f"{elem_title.text}")

        yield item


@Route.register
def get_video_url(episode_url):

    regex = r'(\bhttps://cdn.+m3u8\b)'

    res = requests.get(episode_url).text
    soup = BeautifulSoup(res, "html.parser")
    stream_link = soup.find('lite-iframe')['src']
    res2 = requests.get(stream_link, headers=headers).text
    soup2 = BeautifulSoup(res2, "html.parser")

    stream_source = soup2.select("script")

    final_url = re.findall(regex, str(stream_source))[0]

    return final_url


@Resolver.register
def open_video(plugin, video_url, video_title):

    vid_url = f"{get_video_url(video_url)}|User-Agent={headers['User-Agent']}&Referer=https://studiouniversal.net"
    return Listitem().from_dict(**{
        "label": video_title,
        "callback" : vid_url,
        "properties": {
            "inputstream.adaptive.manifest_type": "hls",
            "inputstream": "inputstream.adaptive"
        }
    })