from __future__ import unicode_literals

import requests
import urlquick
import re
from bs4 import BeautifulSoup


url = "https://noonoo.tv/drama/6775"

base_url = "https://noonoo.tv"
headers = {'User-Agent' : 'Mozilla/5.0', 'Referer' : 'https://noonoo.tv'}

def get_video_url(episode_url):

    # regex = r'(\bhttps://cdn.+m3u8\b)'

    res = urlquick.get(episode_url, max_age=-1)
    soup = res.parse("div", attrs={"class":"playstart"})

    iframe_elem = soup.iterfind("lite-iframe")

    for i in iframe_elem:
        print(i)

    # videourl = ""
    # res2 = requests.get(stream_link, headers=headers).text
    # soup2 = BeautifulSoup(res2, 'html.parser')
    #
    # stream_source = soup2.select("script")
    #
    # final_url = re.findall(regex, str(stream_source))[0]
    #
    # return final_url
